package com.company.vendingmachine.ui;

/**
 * @author RDuffin
 *
 * This interface defines the emthods that take user input and print output to the console
 */
public interface UserIO {
    void print(String prompt);
    int readInt(String prompt);
    String readString(String prompt);
}
