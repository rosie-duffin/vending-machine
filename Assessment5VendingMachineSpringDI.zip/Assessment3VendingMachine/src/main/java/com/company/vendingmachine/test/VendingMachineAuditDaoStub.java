package com.company.vendingmachine.test;

import com.company.vendingmachine.dao.AuditDao;

import java.io.IOException;

/**
 * @author RDuffin
 *
 * This class is a stub for the AuditDao for testing purposes
 */
public class VendingMachineAuditDaoStub implements AuditDao {

    @Override
    public void writeAuditEntry(String entry) throws IOException{
        //do nothing
    }
}
