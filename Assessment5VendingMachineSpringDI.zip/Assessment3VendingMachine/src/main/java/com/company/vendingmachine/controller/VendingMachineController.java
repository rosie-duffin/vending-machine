package com.company.vendingmachine.controller;

import com.company.vendingmachine.dto.VendingMachine;
import com.company.vendingmachine.service.InsufficientFundsException;
import com.company.vendingmachine.service.ItemInventoryEmptyException;
import com.company.vendingmachine.service.VendingMachineServiceLayer;
import com.company.vendingmachine.ui.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Stream;

/**
 * @author RDuffin
 *
 * This class is the controller - it orchestrates the actions of the service layer and view, as well as running the menu.
 */

public class VendingMachineController {

    // Declaring and instantiating necessary class objects
    private VendingMachineView view = new VendingMachineView();
    private VendingMachineServiceLayer service;

    // Constructor
    public VendingMachineController(VendingMachineView view, VendingMachineServiceLayer service) {
        this.view = view;
        this.service = service;
    }

    // run method runs main menu and calls methods in order
    public void run() throws ItemInventoryEmptyException, InsufficientFundsException, IOException {
        boolean keepGoing = true;
        int menuSelection = 0;

        welcomeUser();

        while (keepGoing) {

            loadProducts();

            displayProductList();

            insertCash();

            menuSelection = getMenuSelection();

            switch (menuSelection) {
                case 1:
                    selectProduct();
                    break;
                case 2:
                    keepGoing = false;
                    break;
                default:
                    unknownCommand();
            }

        }
        saveProducts();
        exitMessage();
    }

    // Call to view to display welcome banner
    private void welcomeUser(){
        view.displayWelcome();
    }

    // Call to the service layer to load inventory
    private void loadProducts() {
        service.loadInventory();
    }

    // Call to the service layer to save inventory
    private void saveProducts() throws IOException {
        service.saveInventory();
    }

    // Get product list from service and call view to print it
    private void displayProductList() {
        view.displayProducts();
        List<VendingMachine> productList = service.getProductList();
        // Lambda to filter for products where inventory is greater than zero
        Stream<VendingMachine> availProducts = productList.stream().filter((p) -> p.getItemInventory() > 0);
        view.printProductList(availProducts);
    }

    // Call to view to get money from user
    private String insertCash() {
        String money = view.getCash();
        return money;
    }

    // Using BigDecimal string constructor to save money as a variable
    private BigDecimal cashIn = new BigDecimal(insertCash());

    // Call to view to get user menu selection
    private int getMenuSelection() {
        return view.printMenuAndGetSelection();
    }

    // Gets product from user via view and passes to service
    private void selectProduct() throws ItemInventoryEmptyException, InsufficientFundsException, IOException {
        String product = view.getProductSelection();
        VendingMachine productToVend = service.vendProduct(product);
        service.getProduct(productToVend, cashIn);
    }

    // Call to view to display unknown command message
    private void unknownCommand() {
        view.displayUnknownCommandBanner();
    }

    // Call to view to display exit message
    private void exitMessage() {
        view.displayExitBanner();
    }

}
