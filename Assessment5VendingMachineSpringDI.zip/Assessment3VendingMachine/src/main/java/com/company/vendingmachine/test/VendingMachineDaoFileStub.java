package com.company.vendingmachine.test;

import com.company.vendingmachine.dao.VendingMachineDao;
import com.company.vendingmachine.dto.VendingMachine;
import com.company.vendingmachine.service.InsufficientFundsException;
import com.company.vendingmachine.service.ItemInventoryEmptyException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author RDuffin
 *
 * This class is a stub of VendingMachineDao for testing purposes
 */
public class VendingMachineDaoFileStub implements VendingMachineDao {

    VendingMachine onlyProduct;

    public VendingMachineDaoFileStub() {
        onlyProduct = new VendingMachine("testProduct");
        onlyProduct.setItemCost("1.00");
        onlyProduct.setItemInventory(1);
    }

    public VendingMachineDaoFileStub(VendingMachine testProduct) {
        this.onlyProduct = testProduct;
    }

    @Override
    public List<VendingMachine> getProducts() {
        List<VendingMachine> productList = new ArrayList<>();
        productList.add(onlyProduct);
        return productList;
    }

    @Override
    public VendingMachine getSelection(String product) throws ItemInventoryEmptyException, InsufficientFundsException {
        Map<String, VendingMachine> products = new HashMap<>();
        products.put("testProduct", onlyProduct);

        VendingMachine chosenProduct = products.get("testProduct");
        return chosenProduct;
    }

    @Override
    public void loadInventory() {

    }

    @Override
    public void saveInventory() throws IOException {

    }

}
