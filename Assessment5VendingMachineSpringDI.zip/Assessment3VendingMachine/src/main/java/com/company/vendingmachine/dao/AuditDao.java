package com.company.vendingmachine.dao;

import java.io.IOException;

/**
 * @author RDuffin
 *
 * This interface contains the abstract method for writing to an audit log
 */

public interface AuditDao {
    void writeAuditEntry(String entry) throws IOException;
}
