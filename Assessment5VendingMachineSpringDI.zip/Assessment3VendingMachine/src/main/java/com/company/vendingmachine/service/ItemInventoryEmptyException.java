package com.company.vendingmachine.service;

/**
 * @author RDuffin
 *
 * This class defines the ItemInventoryEmpty exception
 */
public class ItemInventoryEmptyException extends Exception {

    // Created custom exception for case of empty item inventory

    public ItemInventoryEmptyException(String message) {
        super(message);
    }

    public ItemInventoryEmptyException(String message, Throwable cause) {
        super(message, cause);
    }

}
