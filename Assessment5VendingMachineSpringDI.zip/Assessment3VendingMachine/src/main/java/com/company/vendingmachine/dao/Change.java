package com.company.vendingmachine.dao;

import com.company.vendingmachine.controller.VendingMachineController;
import com.company.vendingmachine.service.InsufficientFundsException;
import com.company.vendingmachine.service.VendingMachineServiceLayer;
import com.company.vendingmachine.service.VendingMachineServiceLayerImpl;
import com.company.vendingmachine.ui.UserIO;
import com.company.vendingmachine.ui.UserIOConsoleImpl;
import com.company.vendingmachine.ui.VendingMachineView;

import java.math.BigDecimal;

import static com.company.vendingmachine.dao.Change.Money.*;

/**
 * @author RDuffin
 *
 * This class takes the money entered and calculates the change due to the user
 */
public class Change {

    // Create UserIO object
    UserIO io = new UserIOConsoleImpl();

    // Define denominations of change as enums(more applicable to US currency)
    public enum Money {

        POUND(100), FIFTY(50), TWENTY(20), TEN(10), FIVE(5);

        public final int value;

        Money(int value) {
            this.value = value;
        }

    }

    // Take the money entered and item cost, convert them to double and then multiply by 100
    // to get integers that can be manipulated to find the amount of change due
    public void calculateChange(BigDecimal moneyIn, String itemCost) throws InsufficientFundsException {
        double cost = Double.parseDouble(itemCost);
        double money = moneyIn.doubleValue();
        int intCost = (int) (cost * 100);
        int intMoney = (int) (money * 100);
        int difference = intMoney - intCost;
        if (difference < 0) {
            throw new InsufficientFundsException("You haven't inserted enough money for that product! You inserted " + moneyIn);
        } else if (difference == 0) {
            io.print("No change! Enjoy your product.");
        } else {
            int changePounds = difference / POUND.value;
            io.print("Your change is: " + "£" + changePounds);
            int remainder = difference % POUND.value;
            int changeFifties = remainder / FIFTY.value;
            io.print((changeFifties * FIFTY.value) + "p");
            int remainder2 = difference % FIFTY.value;
            int changeTwenties = remainder2 / TWENTY.value;
            io.print((changeTwenties * TWENTY.value) + "p");
            int remainder3 = difference % TWENTY.value;
            int changeTens = remainder3 / TEN.value;
            io.print((changeTens * TEN.value) + "p");
            int remainder4 = difference % TEN.value;
            int changeFives = remainder4 / FIVE.value;
            io.print((changeFives * FIVE.value) + "p");
        }
    }

}
