package com.company.vendingmachine.service;

import com.company.vendingmachine.dto.VendingMachine;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

/**
 * @author RDuffin
 *
 * This interface defines the abstract methods for getting a product list,
 * vending a product and loading/saving the inventory
 */
public interface VendingMachineServiceLayer {
    List<VendingMachine> getProductList();
    void getProduct(VendingMachine product, BigDecimal inputCash) throws ItemInventoryEmptyException, InsufficientFundsException, IOException;
    VendingMachine vendProduct(String product) throws ItemInventoryEmptyException, InsufficientFundsException;
    void loadInventory();
    void saveInventory() throws IOException;

}
