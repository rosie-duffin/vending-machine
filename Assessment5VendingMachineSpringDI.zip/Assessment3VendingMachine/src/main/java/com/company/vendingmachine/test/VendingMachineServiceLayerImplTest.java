package com.company.vendingmachine.test;

import com.company.vendingmachine.service.InsufficientFundsException;
import com.company.vendingmachine.service.ItemInventoryEmptyException;
import com.company.vendingmachine.dto.VendingMachine;
import com.company.vendingmachine.service.VendingMachineServiceLayer;

import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.math.BigDecimal;

/**
 * @author RDuffin
 *
 * This class tests that the getProduct method functions and checks that
 * custom exceptions are called when appropriate
 */
class VendingMachineServiceLayerImplTest {

    // Declare service layer object
    private VendingMachineServiceLayer service;

    // Constructor using Spring DI to set up service object
    public VendingMachineServiceLayerImplTest() {
        ApplicationContext appContext = new ClassPathXmlApplicationContext("applicationContext.xml");
        service = appContext.getBean("serviceLayer", VendingMachineServiceLayer.class);
    }

    // Uses canned data to test that the test object in not null and that
    // the inventory is reduced by one when the product is vended
    @Test
    void testGetProduct() throws ItemInventoryEmptyException, InsufficientFundsException, IOException {
        VendingMachine testClone = new VendingMachine("testProduct");
        testClone.setItemCost("1.00");
        testClone.setItemInventory(1);

        BigDecimal moneyTest = new BigDecimal("1.00");

        int inventory = testClone.getItemInventory();
        testClone.setItemInventory(inventory - 1);

        assertNotNull(testClone);
        assertEquals(0, testClone.getItemInventory());
    }

    // Uses canned data to test that the InsufficientFundsException
    // is thrown when appropriate
    @Test
    void testInsufficientFunds() {
        VendingMachine testClone = new VendingMachine("testProduct");
        testClone.setItemCost("1.00");
        testClone.setItemInventory(1);

        BigDecimal moneyTest = new BigDecimal("0.00");

        // Use the assertThrows method and lambda to check that the exception is thrown
        InsufficientFundsException ex = assertThrows(InsufficientFundsException.class, () -> {
            service.getProduct(testClone, moneyTest);
        });

        // Check that the message is what is expected
        String expectedMessage = "You haven't inserted enough money for that product! You inserted " + moneyTest;
        String actualMessage = ex.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    // Uses canned data to test that the ItemInventoryEmptyException
    // is thrown when appropriate
    @Test
    void testItemInventoryEmpty() {
        VendingMachine testClone = new VendingMachine("testProduct");
        testClone.setItemCost("1.00");
        testClone.setItemInventory(0);

        BigDecimal moneyTest = new BigDecimal("1.00");

        // Use the assertThrows method and lambda to check that the exception is thrown
        ItemInventoryEmptyException ex = assertThrows(ItemInventoryEmptyException.class, () -> {
            service.getProduct(testClone, moneyTest);
        });

        // Check that the message is what is expected
        String expectedMessage = "Product inventory is empty!";
        String actualMessage = ex.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

}