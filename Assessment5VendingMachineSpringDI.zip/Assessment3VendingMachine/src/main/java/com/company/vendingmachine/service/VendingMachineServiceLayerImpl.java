package com.company.vendingmachine.service;

import com.company.vendingmachine.dao.*;
import com.company.vendingmachine.dto.VendingMachine;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

/**
 * @author RDuffin
 * <p>
 * This class is the service layer - it calls the getSelection and load/save inventory
 * methods from the DAO, as well as providing the logic to vend a product and calculate
 * change due to the user.
 */
public class VendingMachineServiceLayerImpl implements VendingMachineServiceLayer {

    // Declare dao and audit objects
    VendingMachineDao dao;
    AuditDao audit;
    // Create change object
    Change change = new Change();

    // Constructor
    public VendingMachineServiceLayerImpl(VendingMachineDao dao, AuditDao audit) {
        this.dao = dao;
        this.audit = audit;
    }

    // Calls dao to get a product list
    @Override
    public List<VendingMachine> getProductList() {
        return dao.getProducts();
    }

    // Checks product inventory to see if the product is available, then calculates
    // change due to the user and decrements the item inventory
    @Override
    public void getProduct(VendingMachine product, BigDecimal inputCash) throws ItemInventoryEmptyException, InsufficientFundsException, IOException {
        if (product.getItemInventory() <= 0) {
            throw new ItemInventoryEmptyException("Product inventory is empty!");
        } else {
            change.calculateChange(inputCash, product.getItemCost());
            int inventory = product.getItemInventory();
            product.setItemInventory(inventory - 1);
        }
        audit.writeAuditEntry("Product: " + product + "inventory -1");
    }

    // Calls the dao to get the desired product
    @Override
    public VendingMachine vendProduct(String product) throws ItemInventoryEmptyException, InsufficientFundsException {
        return dao.getSelection(product);
    }

    // Calls the dao to load inventory
    @Override
    public void loadInventory() {
        dao.loadInventory();
    }

    // Calls the dao to save inventory
    @Override
    public void saveInventory() throws IOException {
        dao.saveInventory();
    }


}
