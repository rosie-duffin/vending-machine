package com.company.vendingmachine.ui;

import com.company.vendingmachine.dto.VendingMachine;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.stream.Stream;

/**
 * @author RDuffin
 *
 * This class provides the methods to print output to the console for
 * the user, and take in user input to pass to other methods
 */
public class VendingMachineView {

    // Create UserIO object
    private UserIO io = new UserIOConsoleImpl();

    // Prints the product list using a stream
    public void printProductList(Stream<VendingMachine> productList) {
        // Lambda to print each product's name and cost
        productList.forEach(s -> io.print(s.getItemName() + ", " + s.getItemCost()));
        io.readString("Please hit enter to continue");
    }

    // Gets the money input from the user
    public String getCash() {
        return io.readString("Please insert money (numbers only)");
    }

    // Prints the menu and gets the user's selection
    public int printMenuAndGetSelection() {
        io.print("=== Main Menu ===");
        io.print("1. Select a product");
        io.print("2. Exit");
        return io.readInt("Please select from the above choices.");
    }

    // Gets the product from the user
    public String getProductSelection() {
        String chooseProduct = io.readString("Please choose a product from the list");
        System.out.println(chooseProduct);
        return chooseProduct;
    }

    // Welcome banner
    public void displayWelcome() {
        io.print("=== Welcome! ===");
    }

    // Product list banner
    public void displayProducts() {
        io.print("=== Product List ===");
    }

    // Banner to display to user
    public void displayUnknownCommandBanner() {
        io.print("=== Unknown command ===");
    }

    // Banner to display to user
    public void displayExitBanner() {
        io.print("=== Goodbye! ===");
    }

}
