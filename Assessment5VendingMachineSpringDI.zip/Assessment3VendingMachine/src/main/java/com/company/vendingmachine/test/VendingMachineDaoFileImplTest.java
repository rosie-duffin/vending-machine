package com.company.vendingmachine.test;

import com.company.vendingmachine.dao.VendingMachineDao;
import com.company.vendingmachine.dao.VendingMachineDaoFileImpl;
import com.company.vendingmachine.dto.VendingMachine;
import org.junit.jupiter.api.Test;

import java.io.FileWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @author RDuffin
 *
 * This class tests the methods in the VendingMachineDao
 */
class VendingMachineDaoFileImplTest {

    VendingMachineDao testDao;

    public VendingMachineDaoFileImplTest() {
    }

    // Sets up blank file
    @org.junit.jupiter.api.BeforeEach
    void setUp() throws Exception {
        String testFile = "testInventory.txt";
        // Use the FileWriter to quickly blank the file
        new FileWriter(testFile);
        testDao = new VendingMachineDaoFileImpl(testFile);
    }

    // Uses canned data to test that the product list is functional
    @Test
    void getProducts() {
        VendingMachine product1 = new VendingMachine("product1");
        product1.setItemCost("1.00");
        product1.setItemInventory(1);

        VendingMachine product2 = new VendingMachine("product2");
        product2.setItemCost("2.00");
        product2.setItemInventory(2);

        List<VendingMachine> testProducts = testDao.getProducts();
        testProducts.add(product1);
        testProducts.add(product2);

        assertNotNull(testProducts, "Product list must not be null");
        assertEquals(2, testProducts.size(), "Product list should have two products");

        assertTrue(testProducts.contains(product1), "Product list should contain product1");
        assertTrue(testProducts.contains(product2), "Product list should contain product2");
    }

    // Uses canned data to check that the products map is functional
    @Test
    void getSelection() {
        String itemName = "product1";
        VendingMachine product = new VendingMachine(itemName);
        product.setItemCost("1.00");
        product.setItemInventory(1);

        Map<String, VendingMachine> products = new HashMap<>();
        products.put(itemName, product);

        assertFalse(products.isEmpty());
        assertEquals(1, products.size());
    }

}