package com.company.vendingmachine.dao;

import com.company.vendingmachine.dto.VendingMachine;

import java.io.*;
import java.util.*;

/**
 * @author RDuffin
 *
 * This class provides implementations for the methods defined in the VendingMachineDao interface.
 */
public class VendingMachineDaoFileImpl implements VendingMachineDao {

    // Declare delimiter and file name
    public static final String DELIMITER = ",";
    private final String INVENTORY_FILE;

    // Constructors
    public VendingMachineDaoFileImpl() {
        INVENTORY_FILE = "Inventory/productInventory.txt";
    }

    public VendingMachineDaoFileImpl(String inventoryFile) {
        INVENTORY_FILE = inventoryFile;
    }

    // Map containing VendingMachine objects
    private final Map<String, VendingMachine> products = new HashMap<>();

    // Return a product list
    @Override
    public List<VendingMachine> getProducts() {
        return new ArrayList<VendingMachine>(products.values());
    }

    // Get a product object from the map
    @Override
    public VendingMachine getSelection(String product) {
        VendingMachine chosenProduct = products.get(product);
        return chosenProduct;
    }

    // Unmarshall text strings from file
    private VendingMachine unmarshallVendingMachine (String productAsText) {
        String[] productDetails;
        VendingMachine productFromFile;
        // Split string into array
        productDetails = productAsText.split(DELIMITER);
        // Get product name from array
        String itemName = productDetails[0];
        // Create VendingMachine object
        productFromFile = new VendingMachine(itemName);
        // Set each property of the VendingMachine object
        productFromFile.setItemCost(productDetails[1]);
        productFromFile.setItemInventory(Integer.parseInt(productDetails[2]));
        return productFromFile;
    }

    // Read from productInventory file
    @Override
    public void loadInventory() {
        // Initialise Scanner object
        Scanner scanner = null;
        try {
            // Create BufferedReader for reading the file
            scanner = new Scanner(new BufferedReader(
                    new FileReader(INVENTORY_FILE)));
        } catch (FileNotFoundException e) {
            System.out.println("File not found");
        }
        // Declare the currentLine and currentProduct variables
        String currentLine;
        VendingMachine currentProduct;
        while (scanner.hasNextLine()) {
            // get the next line in the file
            currentLine = scanner.nextLine();
            // Unmarshall line into a VendingMachine object
            currentProduct = unmarshallVendingMachine(currentLine);
            // Add the VendingMachine object to the library
            products.put(currentProduct.getItemName(), currentProduct);
        }
        // close reader
        scanner.close();
    }

    // Write to product inventory file
    @Override
    public void saveInventory() {
        // Declare PrintWriter variable
        PrintWriter out = null;
        try {
            // Use PrintWriter to open file
            out = new PrintWriter(new FileWriter(INVENTORY_FILE));
        } catch (IOException e) {
            System.out.println("Could not save inventory data");
        }
        // Declare String variable
        String productAsText;
        // Get list of VendingMachine objects
        List<VendingMachine> productList = this.getProducts();
        for (VendingMachine product : productList) {
            // Get VendingMachine properties one by one and add each property to a
            // String with the delimiter ","
            productAsText = (product.getItemName() + DELIMITER);
            productAsText += (product.getItemCost() + DELIMITER);
            productAsText += (product.getItemInventory());
            out.println(productAsText);
            // Force buffered data to be written to file
            out.flush();
        }
        // Close file
        out.close();
    }

}
