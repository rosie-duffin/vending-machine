package com.company.vendingmachine.dao;

import com.company.vendingmachine.ui.UserIO;
import com.company.vendingmachine.ui.UserIOConsoleImpl;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;

/**
 * @author Rduffin
 *
 * This class implements the AuditDao interface and writes the audit log to a text file
 */


public class AuditDaoImpl implements AuditDao {
    
    UserIO io = new UserIOConsoleImpl();

    public static final String AUDIT_FILE = "audit.txt";

    @Override
    public void writeAuditEntry(String entry) {
        PrintWriter out = null;

        try {
            out = new PrintWriter(new FileWriter(AUDIT_FILE, true));
        } catch (IOException e) {
            io.print("File error");
        }

        LocalDateTime timestamp = LocalDateTime.now();
        out.println(timestamp + " : " + entry);
        out.flush();
    }

}
