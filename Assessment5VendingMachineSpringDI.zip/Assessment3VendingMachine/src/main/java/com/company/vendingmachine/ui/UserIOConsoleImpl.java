package com.company.vendingmachine.ui;

import java.util.Scanner;

/**
 * @author RDuffin
 *
 * This class provides methods to read user input and print output to the console
 */
public class UserIOConsoleImpl implements UserIO {

    // Create a scanner object
    private final Scanner console = new Scanner(System.in);

    // Prints output to the console
    @Override
    public void print(String prompt) {
        System.out.println(prompt);
    }

    // Reads int input
    @Override
    public int readInt(String prompt) {
        System.out.println(prompt);
        int input = console.nextInt();
        console.nextLine();
        return input;
    }

    // Reads String input
    @Override
    public String readString(String prompt) {
        System.out.println(prompt);
        return console.nextLine();
    }
}
