package com.company.vendingmachine.dao;

import com.company.vendingmachine.dto.VendingMachine;
import com.company.vendingmachine.service.InsufficientFundsException;
import com.company.vendingmachine.service.ItemInventoryEmptyException;

import java.io.IOException;
import java.util.List;

/**
 * @author RDuffin
 *
 * This interface defines abstract methods to get a list of products,
 * get the product the user has selected and load/save inventory
 */
public interface VendingMachineDao {

    List<VendingMachine> getProducts();

    VendingMachine getSelection(String product) throws ItemInventoryEmptyException, InsufficientFundsException;

    void loadInventory();

    void saveInventory() throws IOException;
}
