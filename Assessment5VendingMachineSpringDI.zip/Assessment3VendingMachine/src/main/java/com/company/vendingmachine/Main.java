package com.company.vendingmachine;

import com.company.vendingmachine.controller.VendingMachineController;
import com.company.vendingmachine.dao.*;
import com.company.vendingmachine.service.*;
import com.company.vendingmachine.ui.*;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;

/**
 * @author RDuffin
 *
 * This is the app that runs the program via the main class,
 * which calls to the run method of the controller class
 */
public class Main {

    // Using Spring DI to set up controller class
    public static void main(String[] args) throws ItemInventoryEmptyException, InsufficientFundsException, IOException {
        ApplicationContext appContext = new ClassPathXmlApplicationContext("applicationContext.xml");
        VendingMachineController controller = appContext.getBean("controller", VendingMachineController.class);
        controller.run();
    }

}
