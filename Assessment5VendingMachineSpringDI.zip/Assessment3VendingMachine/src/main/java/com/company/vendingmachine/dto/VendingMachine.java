package com.company.vendingmachine.dto;

import java.util.Objects;

/**
 * @author RDuffin
 *
 * This class contains the VendingMAchine object properties and getters/setters for them,
 * as well as equals and hashCode methods for testing purposes
 */
public class VendingMachine {

    // Declare properties of VendingMachine object
    private String itemName;
    private String itemCost;
    private int itemInventory;

    // Constructor
    public VendingMachine(String product) {
        this.itemName = product;
    }

    // Getters/setters
    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemCost() {
        return itemCost;
    }

    public void setItemCost(String itemCost) {
        this.itemCost = itemCost;
    }

    public int getItemInventory() {
        return itemInventory;
    }

    public void setItemInventory(int itemInventory) {
        this.itemInventory = itemInventory;
    }

    // equals method for tests
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        VendingMachine that = (VendingMachine) o;
        return itemInventory == that.itemInventory && itemName.equals(that.itemName) && itemCost.equals(that.itemCost);
    }

    // hashCode method for tests
    @Override
    public int hashCode() {
        return Objects.hash(itemName, itemCost, itemInventory);
    }

    // toString
    @Override
    public String toString() {
        return "VendingMachine{" +
                "itemName='" + itemName + '\'' +
                ", itemCost='" + itemCost + '\'' +
                ", itemInventory=" + itemInventory +
                '}';
    }
}
